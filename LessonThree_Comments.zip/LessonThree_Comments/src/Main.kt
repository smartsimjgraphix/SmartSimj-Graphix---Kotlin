fun main(args: Array<String>){

    /*
    * This is a block comment
    * */

    //These two lines of code are doing something else
    //println("I will comment this  line later")

    println("This is the second line of our code")
}