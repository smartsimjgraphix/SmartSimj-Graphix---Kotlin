
fun main(args: Array<String>){
    print("Hello world\n")
    println("Hello world Simeon")

    print(45)
    println(45+12+10)
}